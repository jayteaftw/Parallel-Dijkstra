/* assert */
#include <assert.h>
/* INFINITY */
#include <math.h>
/* FILE, fopen, fclose, fscanf, rewind */
#include <stdio.h>
/* EXIT_SUCCESS, malloc, calloc, free */
#include <stdlib.h>
/* time, CLOCKS_PER_SEC */
#include <time.h>

#include <mpi.h>

#include <iostream>

#include <chrono>



using namespace std;

#define ROWMJR(R,C,NR,NC) (R*NC+C)
#define COLMJR(R,C,NR,NC) (C*NR+R)
/* define access directions for matrices */
#define a(R,C) a[ROWMJR(R,C,ln,n)]
#define b(R,C) b[ROWMJR(R,C,nn,n)]

static void load(
    const char * const filename,
    int * const np,
    float ** const ap
)
{
    int i, j, n, ret;
    FILE * fp=NULL;
    float * a;

    /* open the file */
    fp = fopen(filename, "r");
    assert(fp);

    /* get the number of nodes in the graph */
    ret = fscanf(fp, "%d", &n);
    assert(1 == ret);

    /* allocate memory for local values */
    a = (float*) malloc(n*n*sizeof(*a));
    assert(a);

    /* read in roots local values */
    for (i=0; i<n; ++i) {
        for (j=0; j<n; ++j) {
        ret = fscanf(fp, "%f", &a(i,j));
        assert(1 == ret);
        }
    }

    /* close file */
    ret = fclose(fp);
    assert(!ret);

    /* record output values */
    *np = n;
    *ap = a;
}

static void dijkstra_mpi(   const int s, 
                        const int n, 
                        const float * const a, 
                        float ** const lp,
                        int rank,
                        int world_size){
    


    
    MPI_Barrier(MPI_COMM_WORLD);

    int i, j;
    struct float_int {
        float l;
        int u;
    } min;
    char * m;
    float * l;

    

    int *process_prefix_sum;
    process_prefix_sum= (int*)calloc(world_size+1, sizeof(*process_prefix_sum));
    assert(process_prefix_sum);
    
    int a_buf_rank;
    float *a_buf;
    a_buf = (float*) malloc(n*sizeof(*a_buf));
    
    int block_size;
    block_size = (n / world_size);
    if (n % world_size != 0){
        block_size += 1;
    }

    for(i=1; i<world_size+1;++i){
        if ((process_prefix_sum[i-1]+block_size) <= n)
            process_prefix_sum[i] = process_prefix_sum[i-1]+block_size;
        else
            process_prefix_sum[i] = n;
               
    }
    process_prefix_sum[i] = n;
    
    /* for(i=0;i<world_size+1;++i){
        cout<<"Rank:"<<rank<<" "<<process_prefix_sum[i]<<endl;
    } */

    //Size of n for that cluster
    int cluster_n = process_prefix_sum[rank+1] - process_prefix_sum[rank];
    int cluster_prefix = process_prefix_sum[rank];

    //cout<<"Rank:"<<rank<<" "<<cluster_n<<" "<<cluster_prefix<<endl;
    //Init each process cluster's m and l
    m = (char*) calloc(cluster_n, sizeof(*m)); //Cluster
    assert(m);

    l = (float*) malloc(cluster_n*sizeof(*l));
    assert(l);

    
    //Find rank that contains column s in a
    a_buf_rank = 0;
    for(i=0; i<=world_size; i++){
        if (s >= process_prefix_sum[i] and s < process_prefix_sum[i+1]){
            a_buf_rank = i;
            break;
        }
    }

    if(rank == a_buf_rank ){
        //min_u_buffer[0] = min.u;
        for(j=0; j<n; j++){

            a_buf[j] = a((s-cluster_prefix),j);
            //cout<<a_buf[j]<<endl;
        }
        
    }
    
    //cout<<"a_buf rank"<<a_buf_rank<<endl;
    //MPI_Bcast(&min_u_buffer, 1, MPI_INT, a_buf_rank, MPI_COMM_WORLD);
    MPI_Bcast(a_buf, n, MPI_FLOAT, a_buf_rank, MPI_COMM_WORLD);


    //Adds all the current path from current source
    for (i=0; i<cluster_n; ++i) {
        //l[i] = a((i+cluster_prefix),s);
        l[i] = a_buf[i+cluster_prefix];
    }
    
    //Chnage m[s] to 1 if s is in cluster's range
    if(s >= cluster_prefix and s < process_prefix_sum[rank+1]){
        m[s - cluster_prefix] = 1;
    }
    
    min.u = -1; /* avoid compiler warning */

    //Loops through each source
    for (i=1; i<n; ++i) {
        min.l = INFINITY;

        /* find local minimum in sub cluster*/
        for (j=0; j<cluster_n; ++j) {
            if (!m[j] && l[j] < min.l) { //If not in cluster and val < min
                min.l = l[j];
                min.u = j;
            }
        }





        
        //sync, find min, and send min to all othere nodes
        if(rank == 0){
            int process_min[1];
            float min_l_buffer[1];
            int val_buffer[1];
            process_min[0] = 0;

            for(j=1; j<world_size;j++)
            {       
                MPI_Recv(&min_l_buffer, 1, MPI_FLOAT, j,j, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                if (min_l_buffer[0] < min.l){
                    min.l = min_l_buffer[0];
                    process_min[0] = j;
                }
            }
            
            for(j=1; j<world_size;j++)
            {   
                if(j== process_min[0]){
                    val_buffer[0] = 1;
                    MPI_Send(&val_buffer,1,MPI_INT,j,0, MPI_COMM_WORLD);

                }
                else{
                    val_buffer[0] = 0;
                    MPI_Send(&val_buffer,1,MPI_INT,j,0, MPI_COMM_WORLD);
                    MPI_Send(&min.l,1,MPI_FLOAT,j,0, MPI_COMM_WORLD);
                    MPI_Send(&process_min,1,MPI_INT,j,0, MPI_COMM_WORLD);
                }
            }
            a_buf_rank = process_min[0]; 
            if (process_min[0] == 0){
                m[min.u] = 1;
                
            }

        }
        else{
            int return_val[1]; 
            float min_l_buffer[1];
            int process_min_buffer[1];
            

            min_l_buffer[0] = min.l;

             //Send to master thread sub cluster's min.
            MPI_Send(&min_l_buffer,1, MPI_FLOAT,0, rank, MPI_COMM_WORLD);

            //Recieve back if min is current global min
            MPI_Recv(&return_val,1,MPI_INT,0,0,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            //Add node to sub cluster and create a_buf
            if(return_val[0] == 1){
                m[min.u] = 1;
                //min.u += cluster_prefix;
                a_buf_rank = rank;
                     
            }
            else{
                //Recieve back new min.u and min.l
                MPI_Recv(&min_l_buffer,1,MPI_FLOAT,0,0,MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                MPI_Recv(&process_min_buffer,1,MPI_INT,0,0,MPI_COMM_WORLD, MPI_STATUS_IGNORE);

                min.l = min_l_buffer[0];
                a_buf_rank = process_min_buffer[0];

            }

        } 
        
        //If a_buf_rank, write min.u column to a_buf
        //int min_u_buffer[1];
        if(rank == a_buf_rank ){
            //min_u_buffer[0] = min.u;
            for(j=0; j<n; j++){
                a_buf[j] = a(min.u,j);
                //cout<<a_buf[j]<<endl;
            }
        }
        //cout<<"a_buf rank"<<a_buf_rank<<endl;
        //MPI_Bcast(&min_u_buffer, 1, MPI_INT, a_buf_rank, MPI_COMM_WORLD);
        MPI_Bcast(a_buf, n, MPI_FLOAT, a_buf_rank, MPI_COMM_WORLD);
        MPI_Barrier(MPI_COMM_WORLD);
        //min.u = min_u_buffer[0];
        //Update nodes with min.l
        for (j=0; j<cluster_n; ++j) {
            //If node not in cluster, add current prefix to that node if the sum is less than current value
            if (!m[j] && min.l+a_buf[j+cluster_prefix] < l[j]) {
                //l[j] = min.l+a((j+cluster_prefix),min.u);
                l[j] = min.l+a_buf[j+cluster_prefix];

                /* if (a_buf[j+cluster_prefix] != a((j+cluster_prefix),min.u)){
                    cout<<a_buf[j+cluster_prefix]<<" "<<a((j+cluster_prefix),min.u)<<endl;
                } */
            }
                
        } 

    }

    
    //Gather all results back
    if(rank == 0){
        float *l_final, *l_final_buffer;
        l_final = (float*) malloc(n*sizeof(*l_final));
        int idx = 0;
        int l_buffer_size = 0;
        for(i=0;i<cluster_n;i++){
           l_final[idx] = l[i];
           idx ++;
        }
        for(j=1; j<world_size;j++)
        {   
            if (l_buffer_size != (process_prefix_sum[j+1] - process_prefix_sum[j]))
            {
                l_buffer_size = int(process_prefix_sum[j+1] - process_prefix_sum[j]);
                l_final_buffer = (float*) malloc(l_buffer_size*sizeof(*l_final_buffer));
            }

            MPI_Recv(l_final_buffer, l_buffer_size, MPI_FLOAT, j,j, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            for(i=0;i<l_buffer_size;i++){
                l_final[idx] = l_final_buffer[i];
                //cout<<"Rank, "<<rank<<", idx: "<<i<<", val:"<<l_final_buffer[i]<<endl;
                idx ++;
                }
        } 
        *lp = l_final;
        
    }
    else{
        MPI_Send(l, cluster_n, MPI_FLOAT, 0,rank, MPI_COMM_WORLD);
        free(l);
        *lp = NULL;

    }
    free(a_buf);

}



static void
print_time(const double seconds)
{
  printf("Search Time: %0.06fs\n", seconds);
}

static void
print_numbers(
  const char * const filename,
  const int n,
  const float * const numbers)
{
  int i;
  FILE * fout;

  /* open file */
  if(NULL == (fout = fopen(filename, "w"))) {
    fprintf(stderr, "error opening '%s'\n", filename);
    abort();
  }

  /* write numbers to fout */
  for(i=0; i<n; ++i) {
    fprintf(fout, "%10.4f\n", numbers[i]);
  }

  fclose(fout);
}

int
main(int argc, char ** argv)
{
    int n;
    float * a, * l;
    
    if(argc < 3){
        printf("Invalid number of arguments.\nUsage: dijkstra <graph> <num_sources> [<output_file>].\n");
        return EXIT_FAILURE;
    }


    // Initialize the MPI environment
    MPI_Init(NULL, NULL);

    // Get the number of processes
    int world_size;
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    int rank;
    // Get the rank of the process
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);


    



    /* initialize random seed: */
    srand (time(NULL));
    unsigned int seed = time(NULL);

    /* figure out number of random sources to search from */
    int nsources = atoi(argv[2]);
    assert(nsources > 0);

    /* load data */
    int buff_n[1];
    if(rank == 0){
        load(argv[1], &n, &a);
        buff_n[0] = n;

        //Transpose a
        for(int x = 0; x < n; x++){
            for(int y = 0; y < n; y++){
                a(y,x) = a(x,y);
            }
        }

        int *process_prefix_sum;
        process_prefix_sum= (int*)calloc(world_size+1, sizeof(*process_prefix_sum));
        assert(process_prefix_sum);
        
        
        int block_size;
        block_size = (n / world_size);
        if (n % world_size != 0){
            block_size += 1;
        }

        int i=0;
        for(i=1; i<world_size+1;++i){
            if ((process_prefix_sum[i-1]+block_size) <= n)
                process_prefix_sum[i] = process_prefix_sum[i-1]+block_size;
            else
                process_prefix_sum[i] = n;
                
        }
        process_prefix_sum[i] = n;
        
        float *a_buffer;
        int n_buff[1];
        n_buff[0] = n;
        int a_buffer_size[1];
        int idx = 0;
        for(int j=1; j<world_size; j++){
            a_buffer_size[0] = n*(process_prefix_sum[j+1] - process_prefix_sum[j]);
            a_buffer = (float*) malloc(a_buffer_size[0]*sizeof(*a_buffer)); 
            idx = 0;
            for(int x = process_prefix_sum[j]; x < process_prefix_sum[j+1]; x++){
                for(int y = 0; y < n; y++){
                    a_buffer[idx] = a(x,y);
                    idx++;
                }
            }
            MPI_Send(&a_buffer_size, 1, MPI_INT, j,j, MPI_COMM_WORLD);
            MPI_Send(&n_buff, 1, MPI_INT, j,j, MPI_COMM_WORLD);
            MPI_Send(a_buffer, a_buffer_size[0], MPI_FLOAT, j,j, MPI_COMM_WORLD);
        }
        
    }
    else{
        
        int size[1];
        int n_buff[1];
        MPI_Recv(&size ,1, MPI_INT, 0,rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&n_buff ,1, MPI_INT, 0,rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        n = n_buff[0];
        a = (float*) malloc(size[0]*sizeof(*a));
        MPI_Recv(a, size[0], MPI_FLOAT, 0,rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

    }
    MPI_Barrier(MPI_COMM_WORLD);

    /*  MPI_Bcast(a, n*n, MPI_FLOAT, 0, MPI_COMM_WORLD);
    MPI_Barrier(MPI_COMM_WORLD);
    MPI_Bcast(buff_n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    n = buff_n[0];
    MPI_Barrier(MPI_COMM_WORLD);  */

    /* if(rank == 0){
        printf("Loading graph from %s.\n", argv[1]);
        load(argv[1], &n, &a);

        int *process_prefix_sum;
        process_prefix_sum= (int*)calloc(world_size+1, sizeof(*process_prefix_sum));
        assert(process_prefix_sum);
        
        
        int block_size;
        block_size = (n / world_size);
        if (n % world_size != 0){
            block_size += 1;
        }

        int i;
        for(i=1; i<world_size+1;++i){
            if ((process_prefix_sum[i-1]+block_size) <= n)
                process_prefix_sum[i] = process_prefix_sum[i-1]+block_size;
            else
                process_prefix_sum[i] = n;
                
        }
        process_prefix_sum[i] = n;


        float *a_buffer;
        int a_buffer_size[1];
        int n_buff[1];
        n_buff[0] = n;
        a_buffer_size[0] = 0;

        for(int j=1; j<world_size;j++)
        {   
            int n_cluster = (process_prefix_sum[j+1] - process_prefix_sum[j]);
            if (a_buffer_size[0] != n*n_cluster)
            {
                a_buffer_size[0] = n*n_cluster;
                a_buffer = (float*) malloc(a_buffer_size[0]*sizeof(*a_buffer));
            }
            for(int x = process_prefix_sum[j]; x < process_prefix_sum[j+1]; x++){ //Row
                for(int y = 0; y < n; y++){ //Column
                    a_buffer(y,x) = a(y,x); //Transposed

                }
            }

            MPI_Send(&a_buffer_size, 1, MPI_INT, j,j, MPI_COMM_WORLD);
            MPI_Send(&n_buff, 1, MPI_INT, j,j, MPI_COMM_WORLD);
            MPI_Send(a_buffer, a_buffer_size[0], MPI_FLOAT, j,j, MPI_COMM_WORLD);

        }
        int n_cluster = (process_prefix_sum[1] - process_prefix_sum[0]);
        if (a_buffer_size[0] != n*n_cluster)
        {
            a_buffer_size[0] = n*n_cluster;
            a_buffer = (float*) malloc(a_buffer_size[0]*sizeof(*a_final_buffer));
        }
        //Set master's a to sub a matrix
        for(int x = process_prefix_sum[0]; x < process_prefix_sum[1]; x++){ //Row
            for(int y = 0; y < n; y++){ //Column
                a_buffer(y,x)  = a(y,x); //Transposed
            }
        }

        free(a);
        a = a_buffer;


    }else{
        int n_buff[1];
        int size[1];
        MPI_Recv(&size ,1, MPI_INT, 0,0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&n_buff ,1, MPI_INT, 0,0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(a, size[0], MPI_FLOAT, 0,0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        n = n_buff[0];
        cout<<rank<<" "<<n<<" "<<size;
    } */
    if(rank == 0)
        printf("Performing %d searches from random sources.\n", nsources);
    auto start = chrono::high_resolution_clock::now();
    for(int i=0; i < nsources; ++i){
        dijkstra_mpi(rand_r(&seed) % n, n, a, &l, rank, world_size);

    }
    if(rank == 0){
        auto stop = chrono::high_resolution_clock::now();
        auto duration = chrono::duration_cast<chrono::milliseconds>(stop - start);
        cout << duration.count() << " ms" << endl;
    }

    
    if(argc >= 4){ 
        if(rank == 0)
            printf("Computing result for source 0.\n");
        dijkstra_mpi(0, n, a, &l, rank, world_size);
        if (rank == 0){
            printf("Writing result to %s.\n", argv[3]);
            print_numbers(argv[3], n, l);
            free(a);
            free(l);
        }
    }else{
        free(a);
        free(l);
    }
    
    
    
    
    
    

    

  return EXIT_SUCCESS;
}
